<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="tileset2" tilewidth="128" tileheight="128" tilecount="48" columns="8">
 <image source="../Textures/tileset2.png" width="1024" height="768"/>
</tileset>
